# PostgreSQL Coverage Test Case Generation

## 核心文件说明

### 生成逻辑
- **scripts/_build_v23.py**: 从 SQL 模板库构建最终 submission
- **outputs/_improved_sql_v21.json**: 针对每个 commit 设计的 SQL 测试用例库（核心贡献）
- **outputs/submission_v23.json**: 最终提交文件（225 SQL blocks, PrecNF=0.7525）

### 评测脚本
- **scripts/evaluate.py**: 主评测逻辑（extract/check/计算覆盖率）
- **scripts/evaluate_coverage.sh**: 覆盖率收集（启动 PG + gcov + lcov）
- **run_local_eval.sh**: 本地测试入口（可选）

### 分析数据（方法论）
- **outputs/_cold_gaps.json**: 未覆盖行分析
- **outputs/_workflow_analyses.json**: 对抗性可达性验证结果

## 运行方式

```bash
# 检查 submission 格式
python3 scripts/evaluate.py check outputs/submission_v23.json --dataset data/test_v3.json

# 本地评测（需要 PostgreSQL 13.23 源码 + gcov-11）
bash run_local_eval.sh --submission outputs/submission_v23.json --name test
```

## 关键方法

1. **热路径识别**: 通过隔离实验（133-only）识别 9 个热路径 commit，优化其余 COLD commit
2. **对抗性验证**: 用 workflow 深挖每行可达性，用真实 gcov 数据驳回所有"可达"幻觉
3. **GCC 版本差异**: 确认 gcov-11 计数机制，证实参数续行/else 关键字永不获独立计数器
4. **分支覆盖最大化**: 为每个 else 分支补充 SQL，提升命中次数以应对平台 GCC 11.2.1 差异

## 最终指标

- 本地 PrecNF: 0.7525 (149/198 covered)
- SQL blocks: 225
- SQL statements: 1763
- Efficiency: 0.1818
